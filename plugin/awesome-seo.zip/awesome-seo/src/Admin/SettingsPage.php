<?php

namespace AwesomeSEO\Admin;

class SettingsPage {

	public function __construct() {
	}

	public function render() {
	}

}